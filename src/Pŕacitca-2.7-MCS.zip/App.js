import logo from './logo.svg';
import './App.css';
import Contenedor from './Ejercicio2/Contenedor';

function App() {
  return (
    <Contenedor></Contenedor>
  );
}

export default App;
